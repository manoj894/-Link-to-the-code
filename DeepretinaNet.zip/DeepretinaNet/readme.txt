Required MATLAB version 2024a and latest
# Download the trained models RetisegNet.mat and STDeepNet.mat from  https://doi.org/10.6084/m9.figshare.28677701
## Steps for vessel segmentation
Load "RetisegNet.mat" model from "Vesssel Segmentation" folder
Provide image path to "DeepretinaNet\Vesssel Segmentation\testing images\1.jpg"
Run "RetiSegnet_main"

## Steps for Disease Classification

Load "STDeepNet" model from "Disease Classification" folder
Provide image path to "DeepretinaNet\Disease Classification\Test images"
Run "STDeepNet_main"

